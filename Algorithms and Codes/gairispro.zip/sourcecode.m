% 
% GENETIC ALGORITHMS FOR IRIS RECOGNITION
%
% In order to obtain the complete source code please visit
% 
% http://www.advancedsourcecode.com/gairis.asp
%
%
% For more information please email us luigi.rosa@tiscali.it
% 
% Luigi Rosa
% Via Centrale 35
% 67042 Civita di Bagno
% L'Aquila - ITALY 
% email luigi.rosa@tiscali.it
% mobile +39 3207214179 
% website http://www.advancedsourcecode.com
%
%